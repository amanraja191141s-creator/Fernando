# SA Calculator v78 — QA Report

## Source provenance
- Built from `SA-Calculator-v77-Independent-Premium-Rebuild.zip` (independent v76 lineage).
- v98.27 through v98.33 archives were not used as the UI, systems or behavior base.
- Previous v77 PWA workflow structure was retained and adapted to v78; the v98.33 Android-specific YAML was not used because this source tree does not include Capacitor/Gradle Android project files.

## Automated checks
- `npm test`: **29 passed, 0 failed**.
- JavaScript syntax checks cover tool-options.js, app.js, premium-ui.js, server.js, service-worker.js and build.js.
- `npm run build`: passed; 11 required runtime/brand assets copied into `dist/`.
- Service-worker precache includes the new tool option registry and all runtime assets.
- Currency flag mapping covers every code in the static selectable currency catalogue.
- Workflow YAML parses successfully; packaging steps validate source ZIP and upload source/web artifacts.

## Not physically verified
- No native Android APK/Gradle build is possible from this PWA source baseline.
- No physical handset/WebView screenshot, IME, FPS, memory, battery or live currency-network test was run in this environment.
