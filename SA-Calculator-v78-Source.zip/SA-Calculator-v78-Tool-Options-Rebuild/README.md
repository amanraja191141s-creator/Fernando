# SA Calculator — v78 Tool Options Rebuild

## Source selection (important)
This release is built from the independent **v77 Premium Rebuild** source tree, which was itself rebuilt from the v76 baseline. It does **not** use the v98.27–v98.33 ZIPs as its UI, systems or behavior base.

## v78 options and behavior work
- Added an explicit registry for all 17 tools and Settings, documenting their selectable options, input rules, validation, results and state behavior.
- Long select lists now have an in-dialog search field, no-results state, one close action, keyboard navigation and focus restoration.
- Loan starts with blank principal/rate/period and neutral results; interest-only months default to zero. Demo-looking values removed.
- Discount Calculator now supports tax added after discount or tax already included in the price.
- Body Metrics supports cm/in and kg/lb; BMI works without gender while BMR clearly requires gender.
- Date Calculator now includes a date-difference calculator alongside saved dates and yearly anniversaries.
- Fuel Cost supports km/mi and km/L, L/100 km or US MPG, with explicit conversion factors.
- Unit Price requires at least two valid products and a shared quantity unit for fair comparison.
- Tip Calculator includes 10/15/18/20% quick presets.
- Percent modes use clear labels; Sales Tax labels change with inclusive/exclusive mode.
- Existing currency providers/cache, calculator parser, memory, settings, history, favorites, date events and brand assets are retained.

## Provenance
- Baseline archive: `SA-Calculator-v77-Independent-Premium-Rebuild.zip`.
- The v98.33 Android workflow was reviewed but not copied because this source tree has no Capacitor/Gradle project. The v78 workflow follows the prior v77 successful PWA build/test/artifact flow and adds strict version and output checks.

## Run and verify
```sh
npm test
npm run build
npm start
```

## Important QA boundary
Automated tests verify source logic and packaging. They do not certify physical Android WebView rendering, APK installation, live currency provider availability, FPS, memory or battery performance.
