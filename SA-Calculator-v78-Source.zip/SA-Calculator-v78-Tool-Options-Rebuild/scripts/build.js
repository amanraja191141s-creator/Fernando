'use strict';
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const dist = path.join(root, 'dist');
const required = [
  'index.html','manifest.webmanifest','service-worker.js',
  'assets/css/app.css','assets/js/tool-options.js','assets/js/app.js','assets/js/premium-ui.js',
  'assets/brand/sa-calculator-icon-192.png','assets/brand/sa-calculator-icon-512.png',
  'assets/brand/apple-touch-icon.png','assets/brand/favicon-64.png'
];
for (const file of required) {
  const full = path.join(root, file);
  if (!fs.existsSync(full)) throw new Error(`Required release asset missing: ${file}`);
}
fs.rmSync(dist, { recursive: true, force: true });
for (const file of required) {
  const source = path.join(root, file);
  const target = path.join(dist, file);
  fs.mkdirSync(path.dirname(target), { recursive: true });
  fs.copyFileSync(source, target);
}
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
const manifest = JSON.parse(fs.readFileSync(path.join(root, 'manifest.webmanifest'), 'utf8'));
if (manifest.version !== pkg.version) throw new Error('Package and PWA manifest versions differ');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
for (const asset of ['assets/css/app.css','assets/js/tool-options.js','assets/js/app.js','assets/js/premium-ui.js']) {
  if (!html.includes(asset)) throw new Error(`index.html does not load ${asset}`);
}
fs.writeFileSync(path.join(dist, 'BUILD-INFO.txt'), `SA Calculator ${pkg.version}\nBuilt from the independent v76 lineage using the v77 source baseline; v98.27–v98.33 were not used.\n`);
console.log(`Built ${pkg.name} ${pkg.version} into dist/ (${required.length} verified assets).`);
