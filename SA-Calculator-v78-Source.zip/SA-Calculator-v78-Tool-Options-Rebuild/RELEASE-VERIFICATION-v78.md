# SA Calculator v78 Release Verification

- Release: `1.84.0-v78`
- Source baseline: independent v77 Premium Rebuild (v76 lineage).
- Excluded as source/UI/system bases: v98.27, v98.28, v98.29, v98.30, v98.31, v98.32, v98.33.
- Android-specific v98.33 YAML was not copied because this source does not contain Capacitor or Gradle project files. The delivered workflow follows the v77 PWA workflow model and retains the full successful checks: test, syntax, web build, source ZIP, web-build artifact.

## Local verification
- `npm test`: 29 passed, 0 failed.
- `npm run build`: passed; 11 required assets copied to `dist/`.
- JavaScript syntax checks: passed for tool-options.js, app.js, premium-ui.js, server.js, service-worker.js and build.js.
- YAML parsed successfully with PyYAML.
- Currency flag map: every currency in the selectable static ISO catalog has an explicit region mapping; unmapped future provider codes safely use a globe marker rather than a guessed incorrect flag.
- Source ZIP and web-build ZIP integrity: checked after packaging.

## Not verified in this environment
- Physical Android installation or APK build.
- Android WebView/IME visual rendering on a handset.
- Live exchange-rate provider reachability from the user's device.
- FPS, memory, battery or thermal behavior.

This is a source/PWA release with automated checks, not a physical-device-certified APK release.
