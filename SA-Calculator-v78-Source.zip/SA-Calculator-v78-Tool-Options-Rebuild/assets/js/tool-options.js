/* SA Calculator v78: explicit tool-option registry and pure conversion helpers. */
(function (root) {
  'use strict';
  const TOOL_OPTIONS = Object.freeze({
    currencies: { label:'Currency Converter', selectors:['From currency','To currency'], actions:['Search by country, region, currency name or ISO code','Swap currencies','Refresh live rates'], entry:'Amount field opens numeric keypad; search uses text keyboard', states:['Idle','Loading','Live rate','Cached rate','Offline/error','Unsupported pair'] },
    units: { label:'Unit Converter', categories:['Length','Mass / Weight','Area','Volume','Time','Temperature','Energy','Power','Pressure','Speed','Fuel Efficiency','Data Size'], actions:['From unit','To unit','Swap units'], entry:'Amount field opens numeric keypad' },
    discount: { label:'Discount Calculator', options:{taxTreatment:['Add tax after discount','Tax already included in price']}, fields:['Tax rate','Original price','Discount percent'], results:['Amount saved','Tax amount','Final price'] },
    percent: { label:'Percent Calculator', modes:['Percent Change','Percent Of'], fields:{change:['Initial value','Final value'],of:['Percent','Value']} },
    salestax: { label:'Sales Tax Calculator', modes:['Exclusive (+ Tax)','Inclusive (- Tax)'], fields:['Tax rate','Price before tax / Price including tax'], results:['Tax amount','Total price'] },
    bodymetrics: { label:'Body Metrics', options:{heightUnit:['cm','in'],weightUnit:['kg','lb'],gender:['Male','Female']}, fields:['Height','Weight','Age'], results:['BMI','BMI category','BMR estimate'] },
    date: { label:'Date Calculator', modes:['Date Difference','Saved Dates & Anniversaries'], options:['Start date','End date','Include end date','Event name','Event date','Repeat every year'] },
    fuelcost: { label:'Fuel Cost', options:{distanceUnit:['km','mi'],efficiencyUnit:['km/L','L/100 km','US MPG']}, fields:['Distance','Fuel efficiency','Fuel price per litre'], results:['Fuel required','Total fuel cost'] },
    fuelefficiency: { label:'Fuel Efficiency', method:'Fill-to-fill', fields:['Fuel before refuelling','Fuel after refuelling','Fuel added','Distance travelled'], results:['Fuel consumed','km/L','L/100 km','US MPG'] },
    gradeavg: { label:'Grade Average', options:{gradeScale:'4.0 weighted scale',grades:['A+','A','A-','B+','B','B-','C+','C','C-','D+','D','F']}, actions:['Add subject','Remove subject'], fields:['Subject','Credits','Grade'] },
    hex: { label:'Number Base Converter', bases:['HEX · 16','DEC · 10','OCT · 8','BIN · 2'], actions:['Clear','Cursor left','Cursor right','Delete','Done'], entry:'Base keypad appears only after selecting a base row' },
    loan: { label:'Loan / EMI', options:{repayment:['Equal total payment','Equal principal']}, fields:['Loan principal','Annual interest rate','Loan period (1–1200 months)','Interest-only months (0 to less than loan period)'], results:['First / monthly payment','Total interest','Total payments','Amortization schedule'] },
    savings: { label:'Savings Calculator', options:{frequency:['Simple interest','Annually','Semi-annually','Quarterly','Monthly']}, fields:['Deposit amount','Savings period (years)','Annual interest rate','Interest income tax'], results:['After-tax interest income','Savings balance'] },
    tip: { label:'Tip Calculator', options:{tipPresets:['10%','15%','18%','20%'],taxTreatment:['Tip before tax','Tip on bill amount']}, fields:['Check amount','People count','Tip percent','Tax amount (optional)'], results:['Tip amount','Final total','Per-person amount'] },
    unitprice: { label:'Unit Price Comparison', options:{quantityUnit:['items','g','kg','mL','L','cm','m']}, products:'A–D', rule:'All compared quantities must use the same selected unit', results:['Per-unit prices','Lowest unit price; requires at least two valid products'] },
    worldtime: { label:'World Time', options:['City / IANA time-zone search','Add city','Remove city'], reference:'Kolkata', behavior:'IANA timezone rules and daylight-saving updates' },
    settings: { label:'Settings', groups:['Display','Theme & Colors','Calculator','Decimal & Number Format','Language','Startup','Favorites','History','Clipboard','Sound & Vibration','Privacy','About & Support'] }
  });

  function finitePositive(value) { return Number.isFinite(value) && value > 0; }
  function calculateDiscount(original, taxRate, discountRate, mode='add') {
    if (![original,taxRate,discountRate].every(Number.isFinite) || original<0 || taxRate<0 || taxRate>1000 || discountRate<0 || discountRate>100 || !['add','included'].includes(mode)) return null;
    const saved=original*discountRate/100, discounted=original-saved;
    const taxAmount=mode==='add'?discounted*taxRate/100:(taxRate===0?0:discounted*taxRate/(100+taxRate));
    const finalPrice=mode==='add'?discounted+taxAmount:discounted;
    return [saved,taxAmount,finalPrice].every(Number.isFinite)?{saved,taxAmount,finalPrice}:null;
  }
  function calculateBodyMetrics(height, heightUnit, weight, weightUnit, age, gender) {
    if (![height,weight,age].every(Number.isFinite) || !finitePositive(height) || !finitePositive(weight) || !finitePositive(age)) return null;
    const heightCm=heightUnit==='in'?height*2.54:height;
    const weightKg=weightUnit==='lb'?weight*0.45359237:weight;
    if (!['cm','in'].includes(heightUnit) || !['kg','lb'].includes(weightUnit) || heightCm<50 || heightCm>300 || weightKg>700 || age>120) return null;
    const bmi=weightKg/Math.pow(heightCm/100,2);
    const bmr=['male','female'].includes(gender)?10*weightKg+6.25*heightCm-5*age+(gender==='male'?5:-161):null;
    if (!Number.isFinite(bmi) || (bmr!==null&&!Number.isFinite(bmr))) return null;
    return {bmi,bmr,heightCm,weightKg,category:bmi<18.5?'Underweight':bmi<25?'Normal Weight':bmi<30?'Overweight':'Obese'};
  }
  function calculateFuelCost(distance, distanceUnit, efficiency, efficiencyUnit, pricePerLitre) {
    if (![distance,efficiency,pricePerLitre].every(Number.isFinite) || !finitePositive(distance) || !finitePositive(efficiency) || pricePerLitre<0) return null;
    const distanceKm=distanceUnit==='mi'?distance*1.609344:distance;
    const kmPerL=efficiencyUnit==='kmpl'?efficiency:efficiencyUnit==='l100'?100/efficiency:efficiencyUnit==='mpg'?efficiency*0.425143707:NaN;
    if (!['km','mi'].includes(distanceUnit) || !Number.isFinite(kmPerL) || kmPerL<=0) return null;
    const fuelLitres=distanceKm/kmPerL, totalCost=fuelLitres*pricePerLitre;
    return [fuelLitres,totalCost].every(Number.isFinite)?{distanceKm,kmPerL,fuelLitres,totalCost}:null;
  }
  function calculateDateDifference(start, end, inclusive=false) {
    const valid=value=>typeof value==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(value)&&(()=>{const [y,m,d]=value.split('-').map(Number);if(y<1||m<1||m>12||d<1)return false;const dt=new Date(0);dt.setUTCHours(0,0,0,0);dt.setUTCFullYear(y,m-1,d);return dt.getUTCFullYear()===y&&dt.getUTCMonth()===m-1&&dt.getUTCDate()===d;})();
    if (!valid(start)||!valid(end)) return null;
    const toUTC=value=>{const [y,m,d]=value.split('-').map(Number);const dt=new Date(0);dt.setUTCHours(0,0,0,0);dt.setUTCFullYear(y,m-1,d);return dt.getTime();};
    const days=Math.abs(toUTC(end)-toUTC(start))/86400000+(inclusive?1:0);
    return Number.isFinite(days)?{days,weeks:Math.floor(days/7),remainingDays:days%7}:null;
  }
  function compareUnitPrices(items, unit='item') {
    if (!Array.isArray(items)) return null;
    const valid=items.filter(item=>item&&Number.isFinite(item.price)&&item.price>=0&&Number.isFinite(item.quantity)&&item.quantity>0).map(item=>({...item,unitPrice:item.price/item.quantity})).filter(item=>Number.isFinite(item.unitPrice));
    if (valid.length<2) return {status:'insufficient',unit,valid};
    const best=Math.min(...valid.map(item=>item.unitPrice));
    const winners=valid.filter(item=>Math.abs(item.unitPrice-best)<=Number.EPSILON*Math.max(1,Math.abs(best))*4);
    return {status:'ready',unit,valid,best,winners};
  }

  const api=Object.freeze({TOOL_OPTIONS,calculateDiscount,calculateBodyMetrics,calculateFuelCost,calculateDateDifference,compareUnitPrices});
  root.SA_TOOL_OPTIONS=TOOL_OPTIONS;
  root.SA_TOOL_MATH=api;
  if (typeof module!=='undefined'&&module.exports) module.exports=api;
})(typeof globalThis!=='undefined'?globalThis:this);
