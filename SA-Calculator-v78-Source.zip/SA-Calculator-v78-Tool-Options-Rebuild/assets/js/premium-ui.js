/* SA Calculator v78 interaction layer: searchable navigation, flag currency picker and on-demand tool keypad behavior. */
(() => {
  'use strict';
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));
  const currencyRegion = {
    AED:'AE',AFN:'AF',ALL:'AL',AMD:'AM',ANG:'CW',AOA:'AO',ARS:'AR',AUD:'AU',AWG:'AW',AZN:'AZ',BAM:'BA',BBD:'BB',BDT:'BD',BGN:'BG',BHD:'BH',BIF:'BI',BMD:'BM',BND:'BN',BOB:'BO',BOV:'BO',BRL:'BR',BSD:'BS',BTN:'BT',BWP:'BW',BYN:'BY',BZD:'BZ',CAD:'CA',CDF:'CD',CHE:'CH',CHF:'CH',CHW:'CH',CLF:'CL',CLP:'CL',CNY:'CN',COP:'CO',COU:'CO',CRC:'CR',CUP:'CU',CUC:'CU',CVE:'CV',CZK:'CZ',DJF:'DJ',DKK:'DK',DOP:'DO',DZD:'DZ',EGP:'EG',ERN:'ER',ETB:'ET',EUR:'EU',FJD:'FJ',FKP:'FK',GBP:'GB',GEL:'GE',GHS:'GH',GIP:'GI',GMD:'GM',GNF:'GN',GTQ:'GT',GYD:'GY',HKD:'HK',HNL:'HN',HRK:'HR',HTG:'HT',HUF:'HU',IDR:'ID',ILS:'IL',INR:'IN',IQD:'IQ',IRR:'IR',ISK:'IS',JMD:'JM',JOD:'JO',JPY:'JP',KES:'KE',KGS:'KG',KHR:'KH',KMF:'KM',KPW:'KP',KRW:'KR',KWD:'KW',KYD:'KY',KZT:'KZ',LAK:'LA',LBP:'LB',LKR:'LK',LRD:'LR',LSL:'LS',LYD:'LY',MAD:'MA',MDL:'MD',MGA:'MG',MKD:'MK',MMK:'MM',MNT:'MN',MOP:'MO',MRU:'MR',MUR:'MU',MVR:'MV',MWK:'MW',MXN:'MX',MXV:'MX',MYR:'MY',MZN:'MZ',NAD:'NA',NGN:'NG',NIO:'NI',NOK:'NO',NPR:'NP',NZD:'NZ',OMR:'OM',PAB:'PA',PEN:'PE',PGK:'PG',PHP:'PH',PKR:'PK',PLN:'PL',PYG:'PY',QAR:'QA',RON:'RO',RSD:'RS',RUB:'RU',RWF:'RW',SAR:'SA',SBD:'SB',SCR:'SC',SDG:'SD',SEK:'SE',SGD:'SG',SHP:'SH',SLE:'SL',SLL:'SL',SOS:'SO',SRD:'SR',SSP:'SS',STN:'ST',SVC:'SV',SYP:'SY',SZL:'SZ',THB:'TH',TJS:'TJ',TMT:'TM',TND:'TN',TOP:'TO',TRY:'TR',TTD:'TT',TWD:'TW',TZS:'TZ',UAH:'UA',UGX:'UG',USD:'US',USN:'US',UYI:'UY',UYU:'UY',UYW:'UY',UZS:'UZ',VED:'VE',VES:'VE',VND:'VN',VUV:'VU',WST:'WS',XAF:'CM',XCD:'AG',XOF:'SN',XPF:'PF',YER:'YE',ZAR:'ZA',ZMW:'ZM',ZWL:'ZW'
  };
  const flagFor = code => {
    let region = currencyRegion[code] || '';
    if (region === 'EU') return '🇪🇺';
    if (region === 'UN') return '🇺🇳';
    if (!/^[A-Z]{2}$/.test(region)) return '🌐';
    const points = [...region].map(ch => 127397 + ch.charCodeAt(0));
    try { return String.fromCodePoint(...points); } catch (_) { return '🌐'; }
  };
  const regionName = code => {
    const region = currencyRegion[code] || '';
    if (region === 'EU') return 'European Union';
    if (!/^[A-Z]{2}$/.test(region)) return 'Currency region';
    try {
      const name = new Intl.DisplayNames(['en'], { type: 'region' }).of(region);
      return name && name !== region ? name : 'Currency region';
    } catch (_) { return 'Currency region'; }
  };
  const optionName = option => String(option?.textContent || option?.value || '').trim();

  function initCurrencyPicker() {
    const overlay = $('#currency-picker-overlay');
    const panel = $('.currency-picker-panel', overlay || document);
    const search = $('#currency-picker-search');
    const list = $('#currency-picker-list');
    const title = $('#currency-picker-title');
    const close = $('#currency-picker-close');
    if (!overlay || !panel || !search || !list || !title || !close) return;
    let activeSelect = null;
    let opener = null;
    let entries = [];
    const triggers = new Map();

    function updateTrigger(select) {
      const trigger = triggers.get(select?.id);
      if (!trigger || !select) return;
      const code = select.value || '';
      const option = select.options[select.selectedIndex];
      const name = optionName(option).replace(/\s*[·—-]\s*[A-Z]{3}$/,'');
      $('.currency-flag', trigger).textContent = flagFor(code);
      $('.currency-trigger-code', trigger).textContent = code;
      $('.currency-trigger-name', trigger).textContent = name || code;
      trigger.setAttribute('aria-label', `${select.getAttribute('aria-label') || 'Currency'}: ${name}, ${code}`);
    }
    function makeTrigger(select) {
      if (!select || triggers.has(select.id)) return;
      const trigger = document.createElement('button');
      trigger.type = 'button';
      trigger.className = 'currency-select-trigger';
      trigger.innerHTML = '<span class="currency-flag" aria-hidden="true">🌐</span><span class="currency-trigger-copy"><span class="currency-trigger-code"></span><span class="currency-trigger-name"></span></span><span class="currency-chevron" aria-hidden="true">⌄</span>';
      trigger.addEventListener('click', () => openPicker(select, trigger));
      select.parentNode.insertBefore(trigger, select);
      triggers.set(select.id, trigger);
      select.addEventListener('change', () => updateTrigger(select));
      updateTrigger(select);
    }
    function render(query = '') {
      if (!activeSelect) return;
      list.replaceChildren();
      const q = query.trim().toLocaleLowerCase();
      const filtered = entries.filter(({ code, name, region }) => !q || `${code} ${name} ${region}`.toLocaleLowerCase().includes(q));
      if (!filtered.length) {
        const empty = document.createElement('div'); empty.className = 'currency-empty'; empty.textContent = 'No matching currency found'; list.appendChild(empty); return;
      }
      const fragment = document.createDocumentFragment();
      filtered.forEach(({ code, name, region }) => {
        const button = document.createElement('button'); button.type = 'button'; button.className = `currency-option${activeSelect.value === code ? ' selected' : ''}`; button.setAttribute('role','option'); button.setAttribute('aria-selected', activeSelect.value === code ? 'true' : 'false');
        const flag = document.createElement('span'); flag.className = 'currency-option-flag'; flag.textContent = flagFor(code);
        const copy = document.createElement('span'); copy.className = 'currency-option-copy';
        const label = document.createElement('span'); label.className = 'currency-option-name'; label.textContent = name;
        const regionLabel = document.createElement('span'); regionLabel.className = 'currency-option-region'; regionLabel.textContent = region;
        const iso = document.createElement('span'); iso.className = 'currency-option-code'; iso.textContent = code;
        copy.append(label, regionLabel); button.append(flag, copy, iso);
        button.addEventListener('click', () => choose(code)); fragment.appendChild(button);
      });
      list.appendChild(fragment);
    }
    function openPicker(select, trigger) {
      activeSelect = select; opener = trigger; entries = Array.from(select.options).filter(o => !o.disabled).map(o => ({ code:o.value, name:optionName(o).replace(/\s*[·—-]\s*[A-Z]{3}$/,''), region:regionName(o.value) }));
      title.textContent = select.id === 'cur-from' ? 'Choose source currency' : 'Choose target currency';
      search.value = ''; render(''); overlay.classList.add('active'); overlay.setAttribute('aria-hidden','false'); document.body.style.overflow = 'hidden';
      requestAnimationFrame(() => search.focus({preventScroll:true}));
    }
    function closePicker(restore = true) {
      if (!activeSelect) return;
      const previous = opener; activeSelect = null; opener = null; overlay.classList.remove('active'); overlay.setAttribute('aria-hidden','true'); document.body.style.overflow = '';
      if (restore && previous?.isConnected) previous.focus({preventScroll:true});
    }
    function choose(code) {
      if (!activeSelect) return;
      const select = activeSelect; select.value = code; select.dispatchEvent(new Event('input',{bubbles:true})); select.dispatchEvent(new Event('change',{bubbles:true})); updateTrigger(select); closePicker(true);
    }
    ['cur-from','cur-to'].forEach(id => { const select = document.getElementById(id); if (select) makeTrigger(select); });
    // Currency options are populated asynchronously by the existing currency engine.
    const observer = new MutationObserver(() => { ['cur-from','cur-to'].forEach(id => { const select = document.getElementById(id); if (select) { makeTrigger(select); updateTrigger(select); } }); });
    ['cur-from','cur-to'].forEach(id => { const select = document.getElementById(id); if (select) observer.observe(select,{childList:true}); });
    search.addEventListener('input', () => render(search.value));
    close.addEventListener('click', () => closePicker(true));
    overlay.addEventListener('click', event => { if (event.target === overlay) closePicker(true); });
    document.addEventListener('keydown', event => { if (!activeSelect) return; if (event.key === 'Escape') { event.preventDefault(); closePicker(true); } });
  }

  function initDrawerSearchAndBottomNav() {
    const drawer = $('#sidebar-drawer');
    const search = $('#drawer-search');
    if (search && drawer) {
      search.addEventListener('input', () => {
        const query = search.value.trim().toLocaleLowerCase();
        $$('.drawer-item[data-screen]', drawer).forEach(item => { item.hidden = !!query && !`${item.textContent} ${item.dataset.category || ''} ${item.dataset.screen || ''}`.toLocaleLowerCase().includes(query); });
        $$('.drawer-category-label', drawer).forEach(label => {
          let node = label.nextElementSibling, visible = false;
          while (node && !node.classList.contains('drawer-category-label') && !node.classList.contains('drawer-section-title')) { if (node.matches('.drawer-item[data-screen]') && !node.hidden) visible = true; node = node.nextElementSibling; }
          label.hidden = !!query && !visible;
        });
      });
    }
    const bottom = $('.bottom-nav');
    if (!bottom) return;
    bottom.addEventListener('click', event => {
      const button = event.target.closest('[data-bottom-nav]'); if (!button) return;
      const action = button.dataset.bottomNav;
      if (action === 'calc') window.switchScreen?.('calc');
      else if (action === 'settings') window.openSettingsScreen?.();
      else if (action === 'tools' || action === 'favorites') {
        const drawerButton = $('#btn-drawer-open');
        if ($('#screen-settings')?.classList.contains('active')) { drawerButton?.click(); drawerButton?.click(); }
        else drawerButton?.click();
        if (action === 'tools') { if (search) { search.value=''; search.dispatchEvent(new Event('input')); setTimeout(() => search.focus({preventScroll:true}), 80); } }
        if (action === 'favorites') { search && (search.value=''); search?.dispatchEvent(new Event('input')); setTimeout(() => { const first = $('.drawer-section-title + .drawer-item', drawer); first?.scrollIntoView({block:'nearest'}); }, 80); }
      }
    });
    const sync = () => {
      const active = $('.screen.active'); const id = active?.id?.replace(/^screen-/,'') || 'calc';
      $$('[data-bottom-nav]', bottom).forEach(button => button.classList.toggle('active', button.dataset.bottomNav === (id === 'settings' ? 'settings' : id === 'calc' ? 'calc' : 'tools')));
    };
    const observer = new MutationObserver(sync); $$('.screen').forEach(screen => observer.observe(screen,{attributes:true,attributeFilter:['class']})); sync();
  }

  function initResultStateStyling() {
    const update = () => {
      $$('.result-card').forEach(card => {
        const values = $$('.result-value', card);
        const texts = values.map(node => node.textContent.trim().toLowerCase()).filter(Boolean);
        const empty = texts.length > 0 && texts.every(text => /^(please enter your data|enter your data|enter price and quantity to compare|—|-|n\/a)$/.test(text));
        card.classList.toggle('is-empty', empty);
      });
      $$('.body-metric-result').forEach(card => {
        const text = card.textContent.toLowerCase();
        card.classList.toggle('is-empty', text.includes('enter your data') || text.includes('please enter'));
      });
    };
    update();
    const observer = new MutationObserver(update);
    $$('.result-card, .body-metric-result').forEach(card => observer.observe(card,{childList:true,subtree:true,characterData:true}));
  }

  function initHexPadLifecycle() {
    const keypad = $('#hex-dock-keypad'); if (!keypad) return;
    $$('.hex-convert-row').forEach(row => row.addEventListener('click', () => keypad.classList.add('active')));
    $('[data-hexkey="DONE"]', keypad)?.addEventListener('click', () => keypad.classList.remove('active'));
    const routeObserver = new MutationObserver(() => { if (!$('#screen-hex')?.classList.contains('active')) keypad.classList.remove('active'); });
    $$('.screen').forEach(screen => routeObserver.observe(screen,{attributes:true,attributeFilter:['class']}));
  }

  document.addEventListener('DOMContentLoaded', () => {
    initCurrencyPicker(); initDrawerSearchAndBottomNav(); initHexPadLifecycle(); initResultStateStyling();
    if (typeof window.updateDrawerFavoritesDOM === 'function') window.updateDrawerFavoritesDOM();
  });
})();
