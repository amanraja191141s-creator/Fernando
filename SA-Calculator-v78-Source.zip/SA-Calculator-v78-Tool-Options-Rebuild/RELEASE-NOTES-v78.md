# SA Calculator v78 — Tool Options Rebuild

- Version: `1.84.0-v78`
- Independent base: v77 source archive (v76 lineage); latest v98.27–v98.33 ZIPs were not used as the UI/system base.
- New option registry and searchable long-option picker.
- Loan defaults cleaned; discount tax treatment expanded; BMI/BMR unit choices; date difference added; fuel-cost unit modes added; unit-price fair-comparison rules; tip presets; clearer percent and tax modes.
- Previous v77 workflow structure retained for build, regression tests, syntax checks, source archive and web-build artifact packaging.
- Physical Android device/APK/performance tests remain pending.
