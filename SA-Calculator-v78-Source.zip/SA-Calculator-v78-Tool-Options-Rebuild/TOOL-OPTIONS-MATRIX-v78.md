# SA Calculator v78 — Complete Tool Options & Behaviour Matrix

## Source provenance
- Source/UI/system baseline: the independent **SA-Calculator-v77-Independent-Premium-Rebuild.zip**, which itself documents the v76 independent baseline.
- The v98.27, v98.28, v98.29, v98.30, v98.31, v98.32 and v98.33 archives were **not** used as the source/UI/system base.
- The v98.33 Android YAML was inspected but not copied because this independent v77 lineage is a Node/PWA project and does not contain a Capacitor/Gradle Android project. The v78 workflow preserves the prior v77-style full pass-gate: build, tests, syntax checks, source archive and web-build artifacts.

## Global input and picker rules
- Basic Calculator is the only screen with a permanently visible keypad.
- Every numeric field in other tools opens the shared numeric keypad only when tapped/focused.
- Search/text fields use the text keyboard; date fields use the native date picker; read-only result fields never open a keypad.
- Long native option lists (7+ options) open a searchable option sheet; short lists open a compact option sheet.
- Option sheet has one close action, selected-state indication, keyboard navigation, empty-search state and focus restoration.
- All result cards use neutral empty/invalid states; green is reserved for valid successful results.

## 1. Basic Calculator
- Permanent keypad: digits 0–9, 00, decimal, AC, sign, percent, parentheses, divide, multiply, subtract, add, equals.
- Expression edit: cursor left/right, delete, clear.
- Angle mode: DEG / RAD.
- Memory: MC, MR, M+, M−, MS.
- Scientific actions: π, e, powers, roots, absolute value, reciprocal, log, ln, log₂, factorial, sin/cos/tan, inverse trig and hyperbolic functions.
- Live preview and implicit multiplication follow Settings.

## 2. Currency Converter
- From / To currency selectors; swap action; refresh action.
- Search by country/region, currency name or ISO code; rows show flag, currency name, region and ISO code.
- Amount field: on-demand numeric keypad. Search: text keyboard. Converted amount: read-only.
- States: initial, loading, live rate, cached rate with age, offline/provider error, unsupported pair.
- Rate note must identify source/freshness when available; never present cached data as live.

## 3. Unit Converter
- Categories: Length, Mass/Weight, Area, Volume, Time, Temperature, Energy, Power, Pressure, Speed, Fuel Efficiency, Data Size.
- From unit, To unit, amount, swap.
- Only selected From → To result; no duplicate all-units results panel.
- Numeric keypad only on amount focus.

## 4. Discount Calculator
- Inputs: tax rate, original price, discount percent.
- Tax treatment: **Add tax after discount** (default) or **Tax already included in price**.
- Outputs: amount saved, tax amount, final price.
- Valid ranges: original ≥ 0, tax 0–1000%, discount 0–100%.

## 5. Percent Calculator
- Mode A: Percent Change — Initial value and Final value; signed percentage change; initial value cannot be zero.
- Mode B: Percent Of — Percent and Value; result = percent × value / 100.
- Mode switch preserves each mode's separate entered values.

## 6. Sales Tax Calculator
- Tax rate 0–1000%.
- Mode: Exclusive (+ Tax) or Inclusive (− Tax).
- Exclusive labels: Price before tax, Tax amount, Total price (tax added).
- Inclusive labels: Price including tax, extracted tax amount, Total price (tax included).

## 7. Body Metrics
- Height units: cm / in. Weight units: kg / lb. Age in years. Gender: Male / Female for BMR only.
- BMI calculates from height and weight even if gender has not been selected.
- BMR uses Mifflin–St Jeor and requires gender; result is an estimate, not medical advice.
- Validations: height 50–300 cm equivalent, weight >0 and ≤700 kg equivalent, age 1–120.

## 8. Date Calculator
- Date Difference: Start date, End date, Include end date; outputs total days and weeks + remaining days.
- Date arithmetic uses date-only UTC calendar math to avoid DST drift; reversed dates are supported.
- Saved Dates & Anniversaries: event name, date, repeat yearly, save, edit, delete; Feb 29 recurring events resolve to Feb 28 in non-leap years.

## 9. Fuel Cost
- Distance unit: km / mi.
- Fuel-efficiency unit: km/L / L/100 km / US MPG.
- Fuel price is per litre.
- Outputs: litres required and total fuel cost.
- Conversion uses 1 mile = 1.609344 km and 1 US MPG = 0.425143707 km/L.

## 10. Fuel Efficiency
- Fill-to-fill method: fuel before, fuel after, amount refuelled, distance travelled.
- Formula: consumed fuel = before + added − after.
- Outputs: consumed litres, km/L, L/100 km, US MPG.
- Reject zero/negative distance and non-positive consumed fuel.

## 11. Grade Average
- Dynamic rows: subject name, credits, grade; add/remove; max 100 subjects.
- Grade scale: A+ 4.0, A 4.0, A− 3.7, B+ 3.3, B 3.0, B− 2.7, C+ 2.3, C 2.0, C− 1.7, D+ 1.3, D 1.0, F 0.0.
- Weighted GPA = sum(credits × grade points) / sum(credits).
- Empty/zero-credit rows do not affect GPA; course data persists locally.

## 12. Number Base Converter
- Bases: HEX 16, DEC 10, OCT 8, BIN 2.
- Select a row to edit; other rows synchronize.
- Keypad: valid digits for active base, clear, cursor left/right, delete, Done.
- Maximum 32 input digits; invalid digits are disabled.

## 13. Loan / EMI
- Repayment: Equal total payment or Equal principal.
- Fields: principal, annual interest 0–1000%, period 1–1200 months, interest-only months 0 to less than period.
- No demo values on fresh launch; interest-only months default to 0.
- Outputs: first/regular monthly payment, total interest, total payments, monthly amortization schedule.
- Schedule remains empty until valid principal, rate and period are entered.

## 14. Savings Calculator
- Deposit amount; interest frequency: Simple, Annually, Semi-annually, Quarterly, Monthly.
- Savings period 0–100 years; annual rate ≥0%; interest income tax 0–100%.
- Outputs: after-tax interest income and final savings balance.
- This is a single-deposit model; recurring deposits are not implied.

## 15. Tip Calculator
- Check amount, people count (integer 1–1,000,000), tip 0–1000%, optional tax amount.
- Quick tip presets: 10%, 15%, 18%, 20% (tap fills the tip field).
- Toggle: calculate tip before tax; otherwise tip applies to the full bill amount.
- Outputs: tip amount, final total, amount per person.

## 16. Unit Price Comparison
- Up to four products A–D; each has price and quantity.
- Shared quantity unit: items, g, kg, mL, L, cm, m. All rows are interpreted in this same selected unit.
- Per-unit price for each valid row; best-value comparison requires at least two valid products.
- Equal lowest unit prices are reported as ties; no false winner is shown with only one item.

## 17. World Time
- Base reference: Kolkata.
- Search city or IANA time-zone identifier; select and Add city; remove city cards.
- Time-zone data uses IANA rules and updates with daylight-saving changes where applicable.

## Settings and global preferences
- Display: fullscreen, font size Compact/Standard/Large, keep screen awake.
- Theme: Light/Dark/System; accent palette; OLED black.
- Calculator: DEG/RAD, instant preview, implicit multiplication.
- Number format: Auto/0/2/4/6 decimals; comma/space/lakh/no grouping; trailing zeros.
- Language: English, Hindi, Urdu, Spanish, French, German, Arabic, Chinese.
- Startup: Calculator, any supported tool, or resume last screen; restore previous values.
- Favorites: manage and reset defaults.
- History: record on/off; limits 25/50/100/500; clear with confirmation.
- Clipboard: auto-copy on/off.
- Sound/haptics: key sound, haptic on/off, Light/Medium/Strong vibration.
- Privacy: local-only diagnostics default off; clear cached data is destructive and requires confirmation.
- About/support: version, help guide, feedback and reset settings.

## Explicitly not claimed
- No physical Android device, APK installation, FPS, memory, battery or live-provider network test is included in the automated source QA.
- The project baseline is a PWA/Node source tree, not a native Gradle APK project.
