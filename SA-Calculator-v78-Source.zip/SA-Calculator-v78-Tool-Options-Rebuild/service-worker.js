'use strict';
const CACHE='sa-calculator-v78-shell';
const ASSETS=['./','./index.html','./manifest.webmanifest','./assets/css/app.css','./assets/js/tool-options.js','./assets/js/app.js','./assets/js/premium-ui.js','./assets/brand/sa-calculator-icon-192.png','./assets/brand/sa-calculator-icon-512.png','./assets/brand/apple-touch-icon.png','./assets/brand/favicon-64.png'];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(ASSETS)).then(()=>self.skipWaiting())));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>(key.startsWith('sumaire-')||key.startsWith('sa-calculator-'))&&key!==CACHE).map(key=>caches.delete(key)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{
 const req=event.request;if(req.method!=='GET')return;
 const url=new URL(req.url);if(url.origin!==self.location.origin)return;
 const page=req.mode==='navigate'||req.destination==='document';
 event.respondWith((async()=>{
   const cache=await caches.open(CACHE);
   if(page){try{const fresh=await fetch(req);if(fresh.ok)event.waitUntil(cache.put(req,fresh.clone()).catch(()=>{}));return fresh;}catch(_){return (await cache.match(req))||(await cache.match('./index.html'))||Response.error();}}
   try{const fresh=await fetch(req);if(fresh.ok&&/^(basic|default)$/.test(fresh.type))event.waitUntil(cache.put(req,fresh.clone()).catch(()=>{}));return fresh;}catch(_){return (await cache.match(req))||Response.error();}
 })());
});
