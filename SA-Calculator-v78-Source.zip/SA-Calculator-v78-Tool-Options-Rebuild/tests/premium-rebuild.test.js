'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const ROOT = path.resolve(__dirname, '..');
const read = file => fs.readFileSync(path.join(ROOT, file), 'utf8');

test('v78 is built from the independent v77 source baseline, not a v98 release tree', () => {
  const readme = read('README.md');
  assert.match(readme, /independent \*\*v77 Premium Rebuild\*\* source tree/i);
  assert.match(readme, /does \*\*not\*\* use the v98\.27.*v98\.33 ZIPs/i);
  assert.equal(fs.existsSync(path.join(ROOT, 'assets/css/app.css')), true);
  assert.equal(fs.existsSync(path.join(ROOT, 'assets/js/premium-ui.js')), true);
});

test('all 17 calculator tool destinations remain registered in the rebuilt menu', () => {
  const html = read('index.html');
  const ids = ['calc','currencies','units','discount','percent','salestax','bodymetrics','date','fuelcost','fuelefficiency','gradeavg','hex','loan','savings','tip','unitprice','worldtime'];
  for (const id of ids) {
    assert.match(html, new RegExp(`id="screen-${id}"`), `missing screen ${id}`);
    assert.match(html, new RegExp(`data-screen="${id}"`), `missing menu entry ${id}`);
  }
});

test('only Basic Calculator retains a permanent keypad; every tool uses on-demand entry', () => {
  const html = read('index.html');
  const app = read('assets/js/app.js');
  assert.equal((html.match(/class="main-keypad"/g) || []).length, 1);
  assert.equal((html.match(/class="dock-keypad/g) || []).length, 1, 'only the hidden-until-selected Number Base keypad remains');
  assert.match(app, /PERMANENT_DOCKED_SCREENS\s*=\s*new Set\(\['calc'\]\)/);
  assert.match(app, /input\.dataset\.readonly === 'true'/);
});

test('currency picker supports search, ISO code, region and country flag rendering', () => {
  const html = read('index.html');
  const ui = read('assets/js/premium-ui.js');
  assert.match(html, /id="currency-picker-search"/);
  assert.match(html, /id="currency-picker-list"/);
  assert.match(ui, /const currencyRegion/);
  assert.match(ui, /flagFor\(code\)/);
  assert.match(ui, /regionName\(o\.value\)/);
  assert.match(ui, /search\.addEventListener\('input'/);
  assert.match(read('assets/js/app.js'), /!select\.classList\.contains\('currency-code-select'\)/);
});

test('menu includes searchable categories and bottom navigation actions', () => {
  const html = read('index.html');
  const ui = read('assets/js/premium-ui.js');
  assert.match(html, /id="drawer-search"/);
  assert.match(html, /class="drawer-category-label"/);
  for (const item of ['calc','tools','favorites','settings']) assert.match(html, new RegExp(`data-bottom-nav="${item}"`));
  assert.match(ui, /drawer-search/);
  assert.match(ui, /data-bottom-nav/);
});

test('premium result-state styling separates empty states from successful results', () => {
  const ui = read('assets/js/premium-ui.js');
  const css = read('assets/css/app.css');
  assert.match(ui, /initResultStateStyling/);
  assert.match(ui, /classList\.toggle\('is-empty', empty\)/);
  assert.match(css, /\.result-card\.is-empty/);
});
