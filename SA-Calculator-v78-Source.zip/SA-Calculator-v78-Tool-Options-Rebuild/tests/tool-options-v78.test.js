'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const math=require('../assets/js/tool-options.js');
const ROOT=path.resolve(__dirname,'..');
const read=file=>fs.readFileSync(path.join(ROOT,file),'utf8');

test('explicit tool option registry covers every registered calculator tool and settings',()=>{
  const expected=['currencies','units','discount','percent','salestax','bodymetrics','date','fuelcost','fuelefficiency','gradeavg','hex','loan','savings','tip','unitprice','worldtime','settings'];
  assert.deepEqual(Object.keys(math.TOOL_OPTIONS).sort(),expected.sort());
  for(const id of expected) assert.ok(math.TOOL_OPTIONS[id].label,`missing option label for ${id}`);
});

test('discount mode adds tax after discount or extracts tax from inclusive discounted price',()=>{
  const added=math.calculateDiscount(100,10,20,'add');
  assert.deepEqual(added,{saved:20,taxAmount:8,finalPrice:88});
  const included=math.calculateDiscount(110,10,0,'included');
  assert.equal(included.taxAmount,10);
  assert.equal(included.finalPrice,110);
  assert.equal(math.calculateDiscount(100,10,101,'add'),null);
});

test('BMI and BMR convert imperial measurements correctly and do not require gender for BMI',()=>{
  const metric=math.calculateBodyMetrics(170,'cm',70,'kg',30,'male');
  const imperial=math.calculateBodyMetrics(170/2.54,'in',70/0.45359237,'lb',30,'male');
  assert.ok(Math.abs(metric.bmi-imperial.bmi)<1e-10);
  assert.ok(Math.abs(metric.bmr-imperial.bmr)<1e-8);
  assert.equal(math.calculateBodyMetrics(170,'cm',70,'kg',30,'').bmr,null);
  assert.equal(math.calculateBodyMetrics(0,'cm',70,'kg',30,'male'),null);
});

test('fuel cost converts km, miles, km/L, L/100 km and US MPG to litres consistently',()=>{
  const a=math.calculateFuelCost(100,'km',10,'kmpl',100);
  const b=math.calculateFuelCost(62.137119,'mi',10,'kmpl',100);
  const c=math.calculateFuelCost(100,'km',10,'l100',100);
  const d=math.calculateFuelCost(100,'km',23.5214583,'mpg',100);
  for(const item of [b,c,d]) assert.ok(Math.abs(item.fuelLitres-a.fuelLitres)<0.0001);
  assert.equal(a.fuelLitres,10);
  assert.equal(a.totalCost,1000);
  assert.equal(math.calculateFuelCost(10,'km',0,'kmpl',100),null);
});

test('date difference uses date-only UTC arithmetic, supports reverse order and inclusive end date',()=>{
  assert.deepEqual(math.calculateDateDifference('2026-01-01','2026-01-08'),{days:7,weeks:1,remainingDays:0});
  assert.deepEqual(math.calculateDateDifference('2026-01-08','2026-01-01',true),{days:8,weeks:1,remainingDays:1});
  assert.equal(math.calculateDateDifference('2025-02-29','2025-03-01'),null);
});

test('unit price comparison requires two valid comparable products and reports ties',()=>{
  assert.equal(math.compareUnitPrices([{price:10,quantity:1}]).status,'insufficient');
  const result=math.compareUnitPrices([{key:'A',price:10,quantity:1},{key:'B',price:20,quantity:2},{key:'C',price:30,quantity:2}], 'kg');
  assert.equal(result.status,'ready');
  assert.deepEqual(result.winners.map(x=>x.key),['A','B']);
  assert.equal(result.unit,'kg');
});

test('loan screen starts with blank user inputs and neutral result values, not demo numbers',()=>{
  const html=read('index.html');
  const loan=html.match(/<div class="screen" id="screen-loan">[\s\S]*?<div class="screen" id="screen-savings">/)[0];
  assert.doesNotMatch(loan,/class="input-text">(?:2\.00|100%|332|3)</);
  assert.match(loan,/id="loan-monthly">—/);
  assert.match(loan,/id="loan-interest">—/);
  assert.match(loan,/id="loan-total">—/);
});

test('all native option dialogs have one close action and searchable large option sets',()=>{
  const app=read('assets/js/app.js');
  assert.match(app,/sumaire-picker-search/);
  assert.match(app,/No matching options/);
  assert.doesNotMatch(app,/sumaire-picker-cancel/);
  assert.match(app,/select\.options\.length<7/);
});

test('percent modes are named clearly and date difference plus event manager both exist',()=>{
  const html=read('index.html');
  assert.match(html,/data-percent-mode="change">Percent Change/);
  assert.match(html,/data-percent-mode="of">Percent Of/);
  assert.match(html,/id="date-diff-start"/);
  assert.match(html,/id="date-event-list"/);
  assert.match(html,/id="date-add-event"/);
});

test('fuel and body measurement unit options are available and connected to calculation events',()=>{
  const html=read('index.html'),app=read('assets/js/app.js');
  for(const id of ['bmi-height-unit','bmi-weight-unit','fc-distance-unit','fc-eff-unit']) assert.match(html,new RegExp(`id="${id}"`));
  for(const id of ['bmi-height-unit','bmi-weight-unit','fc-distance-unit','fc-eff-unit']) assert.match(app,new RegExp(`bind\\('${id}'`));
});

test('unit price exposes one shared quantity unit and requires two valid products',()=>{
  assert.match(read('index.html'),/id="up-quantity-unit"/);
  assert.match(read('assets/js/app.js'),/Enter at least two products to compare/);
  assert.match(read('assets/js/tool-options.js'),/All compared quantities must use the same selected unit/);
});

test('tip presets are visible and wired to the tip input',()=>{
  const html=read('index.html'),app=read('assets/js/app.js');
  for(const value of ['10','15','18','20']) assert.match(html,new RegExp(`data-tip-preset="${value}"`));
  assert.match(app,/function initTipPresets/);
});

test('new tool option registry is loaded, built and precached',()=>{
  assert.match(read('index.html'),/assets\/js\/tool-options\.js/);
  assert.match(read('scripts/build.js'),/assets\/js\/tool-options\.js/);
  assert.match(read('service-worker.js'),/tool-options\.js/);
});


test('every selectable ISO currency code has an explicit flag-region mapping',()=>{
  const app=read('assets/js/app.js'),ui=read('assets/js/premium-ui.js');
  const catalog=app.match(/const CURRENCY_CATALOG = \[(.*?)\];/s)[1].match(/"[A-Z]{3}"/g).map(x=>x.slice(1,-1));
  const map=ui.match(/const currencyRegion = \{(.*?)\n  \};/s)[1];
  const mapped=new Set([...map.matchAll(/([A-Z]{3}):/g)].map(x=>x[1]));
  const excluded=new Set(['XAG','XAU','XBA','XBB','XBC','XBD','XDR','XPD','XPT','XSU','XTS','XUA','XXX','MXV','USN','UYI','UYW']);
  assert.deepEqual(catalog.filter(code=>!excluded.has(code)&&!mapped.has(code)),[]);
});
