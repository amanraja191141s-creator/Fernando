'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { spawnSync, spawn } = require('node:child_process');
const http = require('node:http');
const vm = require('node:vm');
const ROOT = path.resolve(__dirname, '..');
const read = p => fs.readFileSync(path.join(ROOT, p), 'utf8');

function request(port, method, pathname) {
  return new Promise((resolve, reject) => {
    const req = http.request({ hostname: '127.0.0.1', port, method, path: pathname }, res => {
      const chunks = []; res.on('data', c => chunks.push(c));
      res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: Buffer.concat(chunks).toString() }));
    });
    req.on('error', reject); req.end();
  });
}

test('JavaScript files parse cleanly', () => {
  for (const file of ['assets/js/tool-options.js', 'assets/js/app.js', 'assets/js/premium-ui.js', 'server.js', 'service-worker.js']) {
    const result = spawnSync(process.execPath, ['--check', path.join(ROOT, file)], { encoding: 'utf8' });
    assert.equal(result.status, 0, `${file}: ${result.stderr}`);
  }
});

test('scientific calculator parser passes arithmetic, functions, implicit multiplication and rejection cases', () => {
  const source = read('assets/js/app.js');
  const start = source.indexOf('function evaluateArithmetic(');
  assert.notEqual(start, -1, 'calculator parser not found');
  const open = source.indexOf('{', start); let depth = 0, end = -1;
  for (let i = open; i < source.length; i++) {
    if (source[i] === '{') depth++;
    else if (source[i] === '}' && --depth === 0) { end = i + 1; break; }
  }
  assert.ok(end > open, 'could not isolate parser function');
  const context = {
    STATE: { isDegMode: false },
    normalizeStandaloneScientificEntry: value => value,
    normalizeScientificExpressionGlyphs: value => value,
    Math, Number
  };
  vm.runInNewContext(`${source.slice(start, end)};globalThis.evaluateArithmetic=evaluateArithmetic;`, context);
  const calc = context.evaluateArithmetic;
  const near = (actual, expected, epsilon = 1e-10) => assert.ok(Math.abs(actual - expected) <= epsilon, `${actual} != ${expected}`);
  near(calc('2+3*4'), 14);
  near(calc('sin(pi/6)'), 0.5);
  near(calc('2pi'), 2 * Math.PI);
  near(calc('sqrt(81)'), 9);
  near(calc('√9'), 3);
  near(calc('200+10%'), 220);
  near(calc('2^3^2'), 512);
  assert.throws(() => calc('1/0'));
  assert.throws(() => calc('alert(1)'));
  assert.throws(() => calc('1+('));
});

test('HTML IDs are unique and literal getElementById references resolve or are documented optional', () => {
  const html = read('index.html');
  const ids = [...html.matchAll(/\bid=["']([^"']+)["']/g)].map(m => m[1]);
  const duplicates = ids.filter((id, i) => ids.indexOf(id) !== i);
  assert.deepEqual([...new Set(duplicates)], []);
  const source = read('assets/js/app.js');
  const refs = [...source.matchAll(/getElementById\(['"]([^'"]+)/g)].map(m => m[1]);
  const missing = [...new Set(refs.filter(id => !ids.includes(id)))];
  assert.deepEqual(missing.sort(), ['btn-header-settings', 'menu-settings', 'unit-all-results'].sort());
  assert.match(source, /if\s*\(list\)\s*list\.replaceChildren\(\)/);
});

test('release version is consistent across app metadata and UI', () => {
  assert.equal(JSON.parse(read('package.json')).version, '1.84.0-v78');
  assert.equal(JSON.parse(read('manifest.webmanifest')).version, '1.84.0-v78');
  assert.match(read('index.html'), /1\.84\.0-v78/);
  assert.match(read('index.html'), /SA Calculator/);
  assert.match(read('server.js'), /SA-Calculator\/1\.84\.0-v78/);
  assert.match(read('service-worker.js'), /sa-calculator-v78-shell/);
});

test('Math Lab feature is fully removed and app is rebranded', () => {
  const html = read('index.html');
  const app = read('assets/js/app.js');
  const css = read('assets/css/app.css');
  assert.doesNotMatch(html, /Math Lab|mathlab|screen-advanced|advanced\.js/i);
  assert.doesNotMatch(app, /Advanced Math Lab|screen-advanced|data-screen.*advanced/i);
  assert.doesNotMatch(css, /#screen-advanced|mathlab-keyboard|advanced-hero/);
  assert.equal(fs.existsSync(path.join(ROOT, 'assets/js/advanced.js')), false);
  assert.equal(fs.existsSync(path.join(ROOT, 'assets/brand/sa-calculator-icon-192.png')), true);
  assert.equal(fs.existsSync(path.join(ROOT, 'assets/brand/sa-calculator-icon-512.png')), true);
  assert.equal(fs.existsSync(path.join(ROOT, 'assets/brand/apple-touch-icon.png')), true);
  assert.equal(fs.existsSync(path.join(ROOT, 'assets/brand/favicon-64.png')), true);
  assert.match(read('manifest.webmanifest'), /SA Calculator/);
});

test('runtime and service-worker precache assets exist', () => {
  const html = read('index.html');
  for (const asset of ['assets/js/tool-options.js', 'assets/js/app.js', 'assets/js/premium-ui.js', 'assets/css/app.css']) {
    assert.ok(fs.existsSync(path.join(ROOT, asset)), `missing ${asset}`);
    assert.ok(html.includes(asset), `index.html does not reference ${asset}`);
  }
  const sw = read('service-worker.js');
  const list = sw.match(/const ASSETS=\[(.*?)\];/s);
  assert.ok(list, 'service worker ASSETS list not found');
  for (const [, asset] of list[1].matchAll(/'([^']+)'/g)) {
    const local = asset === './' ? 'index.html' : asset.replace(/^\.\//, '');
    assert.ok(fs.existsSync(path.join(ROOT, local)), `precache asset missing: ${asset}`);
  }
});

test('CSS has balanced braces and no obvious top-level syntax break', () => {
  const css = read('assets/css/app.css');
  let depth = 0, quote = '', comment = false, escaped = false;
  for (let i = 0; i < css.length; i++) {
    const c = css[i], n = css[i + 1];
    if (comment) { if (c === '*' && n === '/') { comment = false; i++; } continue; }
    if (quote) { if (escaped) escaped = false; else if (c === '\\') escaped = true; else if (c === quote) quote = ''; continue; }
    if (c === '/' && n === '*') { comment = true; i++; continue; }
    if (c === '"' || c === "'") { quote = c; continue; }
    if (c === '{') depth++;
    if (c === '}') { depth--; assert.ok(depth >= 0, 'unexpected closing CSS brace'); }
  }
  assert.equal(depth, 0, 'unbalanced CSS braces');
  assert.equal(comment, false, 'unterminated CSS comment');
  assert.equal(quote, '', 'unterminated CSS string');
});

test('local server serves app safely and rejects invalid methods/paths', async t => {
  const port = 19000 + Math.floor(Math.random() * 1000);
  const child = spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, PORT: String(port) }, stdio: 'ignore' });
  t.after(() => child.kill('SIGTERM'));
  let ready = false;
  for (let i = 0; i < 40; i++) {
    try { const r = await request(port, 'GET', '/'); if (r.status === 200) { ready = true; break; } } catch (_) {}
    await new Promise(r => setTimeout(r, 100));
  }
  assert.ok(ready, 'server did not start');
  const home = await request(port, 'GET', '/');
  assert.equal(home.status, 200);
  assert.match(home.headers['content-type'], /text\/html/);
  assert.equal(home.headers['x-content-type-options'], 'nosniff');
  assert.equal((await request(port, 'GET', '/assets/js/app.js')).status, 200);
  assert.equal((await request(port, 'GET', '/assets/brand/sa-calculator-icon-192.png')).status, 200);
  assert.equal((await request(port, 'GET', '/assets/brand/sa-calculator-icon-512.png')).status, 200);
  assert.equal((await request(port, 'GET', '/.env.example')).status, 404);
  assert.equal((await request(port, 'GET', '/..%2f..%2fetc%2fpasswd')).status, 403);
  const post = await request(port, 'POST', '/'); assert.equal(post.status, 405); assert.equal(post.headers.allow, 'GET, HEAD');
  const head = await request(port, 'HEAD', '/'); assert.equal(head.status, 200); assert.equal(head.body, '');
  const proxy = await request(port, 'GET', '/api/xurrency/USD/EUR/1'); assert.equal(proxy.status, 503);
});


test('brand icon manifest references real PNG assets and approved artwork is wired into UI', () => {
  const manifest = JSON.parse(read('manifest.webmanifest'));
  for (const icon of manifest.icons) assert.equal(fs.existsSync(path.join(ROOT, icon.src)), true, `missing ${icon.src}`);
  const html = read('index.html');
  assert.match(html, /assets\/brand\/sa-calculator-icon-192\.png/);
  assert.match(html, /assets\/brand\/favicon-64\.png/);
  assert.match(html, /apple-touch-icon/);
  assert.doesNotMatch(html, /sumaire-mark\.svg/);
});
